#!/usr/bin/env python3
import json
import subprocess
import sys
import threading
import time

sys.path.insert(0, "/usr/share/orkalinux/lib")
import orka
from orka import Gtk, GLib

HELPER = "/usr/sbin/orka-kopia-helper"

TEXTS = {
    "en": {
        "title": "OrkaLinux Backup", "subtitle": "Restore points: go back in time when something breaks",
        "p_points": "Restore points", "p_settings": "Settings",
        "p_points_sub": "A restore point is a snapshot of the system (apps, settings, drivers). Your own files in the home folder are not part of it and never get removed.",
        "off_title": "Restore points are off", "off_text": "Turn them on and OrkaLinux will keep a few snapshots of the system on this disk.",
        "turn_on": "Turn on", "create": "Create restore point", "refresh": "Refresh",
        "loading": "Loading restore points...", "empty": "No restore points yet.",
        "restore": "Restore", "delete": "Delete",
        "desc_q": "Describe this restore point", "desc_hint": "e.g. Before installing drivers",
        "edit_desc": "Change description", "save": "Save", "first_point": "First restore point",
        "creating": "Creating a restore point... The first one can take several minutes.",
        "created": "Restore point created.", "failed": "It didn't work.", "failed_d": "Details are below and in /var/log/orka-kopia.log. Send them to me on Discord.", "denied": "No password - nothing was changed.",
        "restore_q": "Restore the system to {date}?",
        "restore_q2": "Apps, settings and drivers go back to how they were then. Your files stay. The computer restarts when it's done - save your work first.",
        "delete_q": "Delete the restore point from {date}?", "delete_q2": "This can't be undone.",
        "tag_O": "manual", "tag_D": "daily", "tag_W": "weekly", "tag_M": "monthly", "tag_B": "at boot", "tag_H": "hourly",
        "daily": "A restore point every day", "daily_d": "The last 5 days are kept, older ones are removed by themselves.",
        "auto": "A restore point before updates", "auto_d": "Before installing or updating software (at most once a day).",
        "need_on": "Turn on restore points first.",
    },
    "pl": {
        "title": "Kopia zapasowa OrkaLinux", "subtitle": "Punkty przywracania: cofnij system, gdy coś się zepsuje",
        "p_points": "Punkty przywracania", "p_settings": "Ustawienia",
        "p_points_sub": "Punkt przywracania to zdjęcie systemu (programy, ustawienia, sterowniki). Twoje pliki w katalogu domowym nie wchodzą do niego i nigdy nie są usuwane.",
        "off_title": "Punkty przywracania są wyłączone", "off_text": "Włącz je, a OrkaLinux będzie trzymać kilka kopii systemu na tym dysku.",
        "turn_on": "Włącz", "create": "Utwórz punkt przywracania", "refresh": "Odśwież",
        "loading": "Wczytuję punkty przywracania...", "empty": "Nie ma jeszcze żadnego punktu.",
        "restore": "Przywróć", "delete": "Usuń",
        "desc_q": "Opisz ten punkt przywracania", "desc_hint": "np. Przed instalacją sterowników",
        "edit_desc": "Zmień opis", "save": "Zapisz", "first_point": "Pierwszy punkt przywracania",
        "creating": "Tworzę punkt przywracania... Pierwszy może potrwać kilka minut.",
        "created": "Punkt przywracania utworzony.", "failed": "Nie udało się.", "failed_d": "Szczegóły są niżej i w /var/log/orka-kopia.log. Wyślij mi je na Discordzie.", "denied": "Bez hasła – nic nie zmieniono.",
        "restore_q": "Przywrócić system do stanu z {date}?",
        "restore_q2": "Programy, ustawienia i sterowniki wrócą do tamtego stanu. Twoje pliki zostają. Na koniec komputer się zrestartuje – zapisz wcześniej swoją pracę.",
        "delete_q": "Usunąć punkt przywracania z {date}?", "delete_q2": "Tego nie da się cofnąć.",
        "tag_O": "ręczny", "tag_D": "codzienny", "tag_W": "cotygodniowy", "tag_M": "comiesięczny", "tag_B": "przy starcie", "tag_H": "co godzinę",
        "daily": "Punkt przywracania codziennie", "daily_d": "Zostaje 5 ostatnich dni, starsze znikają same.",
        "auto": "Punkt przywracania przed aktualizacjami", "auto_d": "Przed instalacją albo aktualizacją programów (najwyżej raz dziennie).",
        "need_on": "Najpierw włącz punkty przywracania.",
    },
    "de": {
        "title": "OrkaLinux Sicherung", "subtitle": "Wiederherstellungspunkte: zurück in der Zeit, wenn etwas kaputtgeht",
        "p_points": "Wiederherstellungspunkte", "p_settings": "Einstellungen",
        "p_points_sub": "Ein Wiederherstellungspunkt ist ein Abbild des Systems (Programme, Einstellungen, Treiber). Deine Dateien im Home-Ordner gehören nicht dazu und werden nie gelöscht.",
        "off_title": "Wiederherstellungspunkte sind aus", "off_text": "Schalte sie ein, dann behält OrkaLinux ein paar Systemabbilder auf dieser Festplatte.",
        "turn_on": "Einschalten", "create": "Wiederherstellungspunkt erstellen", "refresh": "Aktualisieren",
        "loading": "Lade Wiederherstellungspunkte...", "empty": "Noch keine Wiederherstellungspunkte.",
        "restore": "Wiederherstellen", "delete": "Löschen",
        "desc_q": "Beschreibe diesen Wiederherstellungspunkt", "desc_hint": "z. B. Vor der Treiberinstallation",
        "edit_desc": "Beschreibung ändern", "save": "Speichern", "first_point": "Erster Wiederherstellungspunkt",
        "creating": "Erstelle Wiederherstellungspunkt... Der erste kann einige Minuten dauern.",
        "created": "Wiederherstellungspunkt erstellt.", "failed": "Das hat nicht geklappt.", "failed_d": "Details stehen unten und in /var/log/orka-kopia.log. Schick sie mir auf Discord.", "denied": "Kein Passwort - nichts geändert.",
        "restore_q": "System auf den Stand vom {date} zurücksetzen?",
        "restore_q2": "Programme, Einstellungen und Treiber kehren zu diesem Stand zurück. Deine Dateien bleiben. Danach startet der Computer neu - speichere vorher deine Arbeit.",
        "delete_q": "Wiederherstellungspunkt vom {date} löschen?", "delete_q2": "Das lässt sich nicht rückgängig machen.",
        "tag_O": "manuell", "tag_D": "täglich", "tag_W": "wöchentlich", "tag_M": "monatlich", "tag_B": "beim Start", "tag_H": "stündlich",
        "daily": "Jeden Tag ein Wiederherstellungspunkt", "daily_d": "Die letzten 5 Tage bleiben, ältere verschwinden von selbst.",
        "auto": "Wiederherstellungspunkt vor Updates", "auto_d": "Vor dem Installieren oder Aktualisieren von Software (höchstens einmal am Tag).",
        "need_on": "Schalte zuerst die Wiederherstellungspunkte ein.",
    },
    "fr": {
        "title": "Sauvegarde OrkaLinux", "subtitle": "Points de restauration : revenir en arrière quand quelque chose casse",
        "p_points": "Points de restauration", "p_settings": "Réglages",
        "p_points_sub": "Un point de restauration est une image du système (applis, réglages, pilotes). Tes fichiers du dossier personnel n'en font pas partie et ne sont jamais supprimés.",
        "off_title": "Les points de restauration sont désactivés", "off_text": "Active-les et OrkaLinux gardera quelques images du système sur ce disque.",
        "turn_on": "Activer", "create": "Créer un point de restauration", "refresh": "Actualiser",
        "loading": "Chargement des points de restauration...", "empty": "Aucun point de restauration pour l'instant.",
        "restore": "Restaurer", "delete": "Supprimer",
        "desc_q": "Décris ce point de restauration", "desc_hint": "ex. Avant d'installer les pilotes",
        "edit_desc": "Modifier la description", "save": "Enregistrer", "first_point": "Premier point de restauration",
        "creating": "Création du point de restauration... Le premier peut prendre plusieurs minutes.",
        "created": "Point de restauration créé.", "failed": "Ça n'a pas marché.", "failed_d": "Les détails sont ci-dessous et dans /var/log/orka-kopia.log. Envoie-les-moi sur Discord.", "denied": "Pas de mot de passe - rien n'a changé.",
        "restore_q": "Restaurer le système au {date} ?",
        "restore_q2": "Applis, réglages et pilotes reviennent à cet état. Tes fichiers restent. L'ordinateur redémarre à la fin - enregistre ton travail avant.",
        "delete_q": "Supprimer le point de restauration du {date} ?", "delete_q2": "Impossible d'annuler.",
        "tag_O": "manuel", "tag_D": "quotidien", "tag_W": "hebdo", "tag_M": "mensuel", "tag_B": "au démarrage", "tag_H": "horaire",
        "daily": "Un point de restauration chaque jour", "daily_d": "Les 5 derniers jours sont gardés, les plus anciens partent tout seuls.",
        "auto": "Un point de restauration avant les mises à jour", "auto_d": "Avant d'installer ou de mettre à jour des logiciels (une fois par jour max).",
        "need_on": "Active d'abord les points de restauration.",
    },
}


def helper(*args):
    try:
        if args and args[0] == "list":
            res = subprocess.run(["pkexec", HELPER, *args], capture_output=True, text=True)
        else:
            res = subprocess.run(["pkexec", HELPER, *args], text=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        return res.returncode, res.stdout
    except OSError as e:
        return 1, str(e)


def tail(text, lines=14):
    return "\n".join((text or "").strip().splitlines()[-lines:])


def nice_date(name):
    try:
        return time.strftime("%d.%m.%Y %H:%M", time.strptime(name, "%Y-%m-%d_%H-%M-%S"))
    except ValueError:
        return name


class OrkaKopia(orka.PagedWindow):
    def __init__(self):
        t = orka.Texts(TEXTS)
        super().__init__("orka-kopia", t["title"], t["subtitle"], "orka-kopia", 900, 640)
        self.t = t
        self.state = None
        self.points = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.settings = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add_page("points", t["p_points"], "document-revert", self.points, t["p_points_sub"])
        self.add_page("settings", t["p_settings"], "configure", self.settings)
        self.show_all()
        if orka.IS_LIVE:
            self.fill(self.points, [orka.card(orka.label(t["live_only_installed"], "text", wrap=True))])
            self.fill(self.settings, [orka.card(orka.label(t["live_only_installed"], "text", wrap=True))])
        else:
            self.reload()

    @staticmethod
    def fill(box, widgets):
        for child in box.get_children():
            box.remove(child)
        for w in widgets:
            box.pack_start(w, False, False, 0)
        box.show_all()

    def busy(self, text):
        row = Gtk.Box(spacing=12)
        spinner = Gtk.Spinner()
        spinner.start()
        row.pack_start(spinner, False, False, 0)
        row.pack_start(orka.label(text, "text", wrap=True), True, True, 0)
        self.fill(self.points, [orka.card(row)])


    def reload(self):
        self.busy(self.t["loading"])
        threading.Thread(target=self._load, daemon=True).start()

    def _load(self):
        code, out = helper("list")
        try:
            state = json.loads(out) if code == 0 else None
        except ValueError:
            state = None
        GLib.idle_add(self.show_state, state, code)

    def show_state(self, state, code):
        self.state = state
        if state is None:
            text = self.t["denied"] if code in (126, 127) else self.t["failed"]
            retry = orka.button(self.t["refresh"], "ghost", self.reload)
            retry.set_halign(Gtk.Align.START)
            self.fill(self.points, [orka.card(orka.label(text, "warn", wrap=True)), retry])
            self.build_settings()
            return False

        if not state["configured"]:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.pack_start(orka.label(self.t["off_title"], "big"), False, False, 0)
            box.pack_start(orka.label(self.t["off_text"], "text", wrap=True), False, False, 0)
            on = orka.button(self.t["turn_on"], "primary", self.turn_on)
            on.set_halign(Gtk.Align.START)
            box.pack_start(on, False, False, 6)
            self.fill(self.points, [orka.card(box)])
            self.build_settings()
            return False

        widgets = []
        top = Gtk.Box(spacing=10)
        top.pack_start(orka.button(self.t["create"], "primary", self.create), False, False, 0)
        top.pack_start(orka.button(self.t["refresh"], "ghost", self.reload), False, False, 0)
        widgets.append(top)
        snaps = sorted(state["snapshots"], key=lambda s: s["name"], reverse=True)
        if not snaps:
            widgets.append(orka.card(orka.label(self.t["empty"], "dim")))
        for snap in snaps:
            widgets.append(self.snapshot_row(snap))
        self.fill(self.points, widgets)
        self.build_settings()
        return False

    def snapshot_row(self, snap):
        row = Gtk.Box(spacing=14)
        icon = Gtk.Image.new_from_icon_name("orka-kopia", Gtk.IconSize.DND)
        icon.set_pixel_size(36)
        row.pack_start(icon, False, False, 0)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        title = Gtk.Box(spacing=8)
        title.pack_start(orka.label(nice_date(snap["name"]), "big"), False, False, 0)
        for tag in snap["tags"]:
            badge = orka.label(self.t["tag_" + tag], "badge")
            badge.set_valign(Gtk.Align.CENTER)
            title.pack_start(badge, False, False, 0)
        texts.pack_start(title, False, False, 0)
        if snap["comment"]:
            texts.pack_start(orka.label(snap["comment"], "dim"), False, False, 0)
        row.pack_start(texts, True, True, 0)
        restore = orka.button(self.t["restore"], "danger", self.restore, snap)
        restore.set_valign(Gtk.Align.CENTER)
        delete = orka.button(self.t["delete"], "ghost", self.delete, snap)
        delete.set_valign(Gtk.Align.CENTER)
        rename = Gtk.Button()
        rename.get_style_context().add_class("ghost")
        rename.add(Gtk.Image.new_from_icon_name(orka.first_icon(["document-edit-symbolic", "document-edit"]),
                                                Gtk.IconSize.BUTTON))
        rename.set_tooltip_text(self.t["edit_desc"])
        rename.set_valign(Gtk.Align.CENTER)
        rename.connect("clicked", lambda *_: self.edit_comment(snap))
        row.pack_end(delete, False, False, 0)
        row.pack_end(restore, False, False, 0)
        row.pack_end(rename, False, False, 0)
        return orka.card(row)


    def in_background(self, text, args, done_text=None):
        self.busy(text)

        def work():
            code, out = helper(*args)
            GLib.idle_add(self.after, code, done_text, out)
        threading.Thread(target=work, daemon=True).start()

    def after(self, code, done_text, out=""):
        if code in (126, 127):
            self.message(self.t["denied"])
        elif code != 0:
            self.message(self.t["failed"], self.t["failed_d"], kind=Gtk.MessageType.ERROR, details=tail(out))
        elif done_text:
            self.message(done_text)
        self.reload()
        return False

    def turn_on(self):
        def work():
            code, out = helper("setup")
            if code == 0:
                code, out = helper("create", self.t["first_point"])
            GLib.idle_add(self.after, code, self.t["created"] if code == 0 else None, out)
        self.busy(self.t["creating"])
        threading.Thread(target=work, daemon=True).start()

    def create(self):
        comment = self.ask_text(self.t["desc_q"], self.t["desc_hint"], self.t["create"], self.t["cancel"])
        if comment is not None:
            self.in_background(self.t["creating"], ["create", comment.strip() or self.t["title"]], self.t["created"])

    def edit_comment(self, snap):
        text = self.ask_text(self.t["edit_desc"], self.t["desc_hint"], self.t["save"], self.t["cancel"],
                             text=snap["comment"])
        if text is not None and text.strip() != snap["comment"]:
            self.in_background(self.t["loading"], ["comment", snap["name"], text.strip()])

    def restore(self, snap):
        date = nice_date(snap["name"])
        if not self.confirm(self.t["restore_q"].format(date=date), self.t["restore_q2"],
                            self.t["restore"], self.t["cancel"], danger=True):
            return
        orka.run_in_terminal(self, ["sudo", HELPER, "restore", snap["name"]], self.t)

    def delete(self, snap):
        date = nice_date(snap["name"])
        if self.confirm(self.t["delete_q"].format(date=date), self.t["delete_q2"], self.t["delete"], self.t["cancel"],
                        danger=True):
            self.in_background(self.t["loading"], ["delete", snap["name"]])


    def build_settings(self):
        state = self.state or {}
        configured = bool(state.get("configured"))
        widgets = []
        for key, value in (("daily", state.get("daily", False)), ("auto", state.get("auto", False))):
            row = Gtk.Box(spacing=14)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            texts.pack_start(orka.label(self.t[key], "big"), False, False, 0)
            texts.pack_start(orka.label(self.t[key + "_d"], "dim", wrap=True), False, False, 0)
            row.pack_start(texts, True, True, 0)
            switch = Gtk.Switch()
            switch.set_valign(Gtk.Align.CENTER)
            switch.set_active(bool(value))
            switch.set_sensitive(configured)
            switch.connect("notify::active", self.on_switch, key)
            row.pack_end(switch, False, False, 0)
            widgets.append(orka.card(row))
        if not configured:
            widgets.append(orka.label(self.t["need_on"], "dim"))
        self.fill(self.settings, widgets)

    def on_switch(self, switch, _param, key):
        def work():
            code, _ = helper(key, "on" if switch.get_active() else "off")
            if code != 0:
                GLib.idle_add(self.after, code, None)
        threading.Thread(target=work, daemon=True).start()


if __name__ == "__main__":
    OrkaKopia()
    orka.run()
