#!/bin/sh
set -e
curl -fsSL https://chatgpt.com/codex/install.sh | sh
