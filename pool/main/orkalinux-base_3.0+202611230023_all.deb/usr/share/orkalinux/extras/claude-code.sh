#!/bin/sh
# Claude Code (asystent w terminalu od Anthropic), oficjalny instalator
# (trafia do ~/.local/bin, bez roota, sam się aktualizuje).
set -e
curl -fsSL https://claude.ai/install.sh | bash
