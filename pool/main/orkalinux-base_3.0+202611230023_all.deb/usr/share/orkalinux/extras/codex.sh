#!/bin/sh
# Codex CLI od OpenAI, oficjalny instalator (trafia do ~/.local/bin, bez roota).
# Ten sam instalator potem aktualizuje Codexa.
set -e
curl -fsSL https://chatgpt.com/codex/install.sh | sh
