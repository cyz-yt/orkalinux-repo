#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OrkaLinux Hello – ekran powitalny OrkaLinux (by _inc0gnit0)
import configparser
import glob
import json
import math
import os
import shlex
import subprocess

import gi
from gi.repository import GLib
# Nazwa zgodna z orkalinux-hello.desktop – dzięki temu okno ma ikonę OrkaLinux na pasku
GLib.set_prgname("orkalinux-hello")
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, Gdk

DISCORD_URL = "https://discord.gg/JkC9P6ebN2"
YOUTUBE_URL = "https://www.youtube.com/@_inc0gnit0"
SITE_URL = "https://cyzs-retroweb.rf.gd/orkalinux.php"
LOGO_WHITE = "/usr/share/pixmaps/orkalinux/orkalinux-logo-white.png"
AUTOSTART_FILE = os.path.expanduser("~/.config/autostart/orkalinux-hello.desktop")
LOOK_DARK = "org.orkalinux.desktop"
LOOK_LIGHT = "org.orkalinux.light.desktop"
IS_LIVE = os.path.exists("/run/live/medium")

TRANSLATIONS = {
    "pl": {
        "title": "Witaj w OrkaLinux!",
        "subtitle": "B3 (Undertow) · by _inc0gnit0",
        "welcome_text_live": "Dzięki za wybranie OrkaLinux! To system oparty na Debianie 13 (Trixie) z pulpitem KDE Plasma. Możesz go wypróbować bez instalacji albo od razu zainstalować na dysku.",
        "welcome_text_installed": "Dzięki za zainstalowanie OrkaLinux! Fajnie, że jesteś w społeczności – mam nadzieję, że zostaniesz na dłużej. _inc0gnit0",
        "btn_readme": "Readme", "desc_readme": "Co jest w systemie",
        "btn_release": "Info o wydaniu", "desc_release": "Co nowego w B3",
        "btn_site": "Strona projektu", "desc_site": "Pobieranie i aktualności",
        "btn_discord": "Discord", "desc_discord": "Pogadaj ze społecznością",
        "btn_youtube": "YouTube", "desc_youtube": "Filmy i poradniki",
        "btn_apps": "Aplikacje", "desc_apps": "Sklep z programami",
        "btn_extras": "Dodatkowe programy", "desc_extras": "Steam, OBS, GIMP i inne",
        "btn_nvidia": "Sterowniki NVIDIA", "desc_nvidia": "Pełna moc karty graficznej",
        "btn_look": "Wygląd systemu OrkaLinux", "desc_look": "Układ, kolory, tapeta, efekty",
        "btn_center": "Centrum OrkaLinux", "desc_center": "Sterowniki, jądro, sprzątanie",
        "btn_backup": "Kopia zapasowa OrkaLinux", "desc_backup": "Punkty przywracania",
        "extras_count": "Zaznaczone: {n}",
        "btn_install": "Zainstaluj OrkaLinux",
        "autostart": "Uruchamiaj przy starcie",
        "dark_mode": "Ciemny motyw",
        "close": "Zamknij",
        "cancel": "Anuluj",
        "extras_title": "Dodatkowe programy",
        "extras_intro": "Zaznacz programy, które chcesz zainstalować. Pobiorą się z Flathuba i będą się same aktualizować razem z resztą systemu (Discover).",
        "extras_install": "Zainstaluj zaznaczone",
        "installed": "zainstalowane",
        "cat_games": "Gry", "cat_create": "Tworzenie", "cat_internet": "Internet i muzyka", "cat_dev": "Praca i inne", "cat_ai": "AI",
        "nvidia_title": "Zainstalować sterownik NVIDIA?",
        "nvidia_text": "OrkaLinux zainstaluje oficjalny sterownik NVIDIA z repozytorium Debiana (ok. 500 MB do pobrania). System zapyta o Twoje hasło, a na koniec trzeba będzie uruchomić komputer ponownie.\n\nJeśli masz włączony Secure Boot, w trakcie instalacji ustawisz jednorazowe hasło do zatwierdzenia sterownika po restarcie – wszystko będzie opisane w oknie instalacji.",
        "nvidia_go": "Instaluj",
        "term_done": "Gotowe! Okno zaraz się zamknie.",
        "term_failed": "Coś poszło nie tak – zrób zrzut tego okna i wyślij mi go na Discordzie OrkaLinux. Enter zamyka okno.",
        "no_terminal": "Nie udało się otworzyć terminala.",
        "readme_text": "OrkaLinux B3 (Undertow)\n================================\n\nOrkaLinux to dystrybucja Linuksa oparta na Debianie 13 (Trixie)\nz pulpitem KDE Plasma, stworzona przez _inc0gnit0.\n\nCo jest w systemie:\n- Firefox - przeglądarka (prosto od Mozilli)\n- Discord - komunikator (aktualizuje się sam)\n- VLC - odtwarzacz multimediów\n- LibreOffice - pakiet biurowy\n- Discover + Flathub - tysiące programów do zainstalowania\n- Drukowanie - drukarki dodasz w Ustawieniach systemowych\n- Fastfetch - informacje o systemie\n- Calamares - instalator systemu\n\nOrkaLinux robi jedna osoba, _inc0gnit0. Jak coś nie działa albo masz pomysł,\nnapisz do mnie na Discordzie, chętnie pogadam.\n\nStrona projektu:\nhttps://cyzs-retroweb.rf.gd/orkalinux.php\n\nDiscord:\nhttps://discord.gg/JkC9P6ebN2\n\nYouTube:\nhttps://www.youtube.com/@_inc0gnit0",
        "release_text": "OrkaLinux B3 (Undertow)\n\nSiema! Co się zmieniło od B2:\n\n- nowy wygląd, ciemny albo jasny (przełącznik na dole tego okna), tapeta zmienia się razem z nim\n- sporo nowych tapet, w tym zdjęcia EC-2\n- okna mają animacje (tak, galaretka przy przeciąganiu jest specjalnie)\n- nowy terminal: kitty, przezroczysty, z rozmyciem, smugą za kursorem i kolorowym promptem\n- Firefox prosto od Mozilli, zawsze najnowszy\n- nowsze jądro, lepiej ogarnia nowy sprzęt\n- Flathub w Discover, więc programów jest dużo więcej\n- Steam, OBS, GIMP i reszta jednym kliknięciem (Dodatkowe programy)\n- sterowniki NVIDIA da się zainstalować z Hello\n- działa drukowanie\n- Discord sam się aktualizuje\n- system jest domyślnie po angielsku, polski wybierasz w menu startowym albo w instalatorze\n\nTo dalej beta, więc coś może się wysypać. Jak coś nie działa, pisz na Discordzie:\nhttps://discord.gg/JkC9P6ebN2\n\nDzięki, że testujesz!",
    },
    "en": {
        "title": "Welcome to OrkaLinux!",
        "subtitle": "B3 (Undertow) · by _inc0gnit0",
        "welcome_text_live": "Thanks for choosing OrkaLinux! It is based on Debian 13 (Trixie) with the KDE Plasma desktop. Try it without installing, or install it to your disk right away.",
        "welcome_text_installed": "Thanks for installing OrkaLinux! Great to have you in the community – I hope you stick around. _inc0gnit0",
        "btn_readme": "Read me", "desc_readme": "What is included",
        "btn_release": "Release info", "desc_release": "What's new in B3",
        "btn_site": "Project website", "desc_site": "Downloads and news",
        "btn_discord": "Discord", "desc_discord": "Chat with the community",
        "btn_youtube": "YouTube", "desc_youtube": "Videos and guides",
        "btn_apps": "Applications", "desc_apps": "Software store",
        "btn_extras": "More software", "desc_extras": "Steam, OBS, GIMP and more",
        "btn_nvidia": "NVIDIA drivers", "desc_nvidia": "Full graphics card power",
        "btn_look": "OrkaLinux Appearance", "desc_look": "Layout, colours, wallpaper, effects",
        "btn_center": "OrkaLinux Center", "desc_center": "Drivers, kernel, cleanup",
        "btn_backup": "OrkaLinux Backup", "desc_backup": "Restore points",
        "extras_count": "Selected: {n}",
        "btn_install": "Install OrkaLinux",
        "autostart": "Launch at startup",
        "dark_mode": "Dark mode",
        "close": "Close",
        "cancel": "Cancel",
        "extras_title": "More software",
        "extras_intro": "Tick the programs you want. They come from Flathub and update together with the rest of the system (Discover).",
        "extras_install": "Install selected",
        "installed": "installed",
        "cat_games": "Games", "cat_create": "Create", "cat_internet": "Internet and music", "cat_dev": "Work and more", "cat_ai": "AI",
        "nvidia_title": "Install the NVIDIA driver?",
        "nvidia_text": "OrkaLinux will install the official NVIDIA driver from the Debian repository (about 500 MB to download). You will be asked for your password, and you will need to restart your computer at the end.\n\nIf Secure Boot is on, you will set a one-time password to approve the driver after the restart – the installer window explains every step.",
        "nvidia_go": "Install",
        "term_done": "Done! This window will close in a moment.",
        "term_failed": "Something went wrong – take a screenshot of this window and send it to me on the OrkaLinux Discord. Press Enter to close.",
        "no_terminal": "Could not open the terminal.",
        "readme_text": "OrkaLinux B3 (Undertow)\n================================\n\nOrkaLinux is a Linux distribution based on Debian 13 (Trixie)\nwith the KDE Plasma desktop, created by _inc0gnit0.\n\nWhat is included:\n- Firefox - web browser (straight from Mozilla)\n- Discord - messenger (updates itself)\n- VLC - media player\n- LibreOffice - office suite\n- Discover + Flathub - thousands of apps to install\n- Printing - add printers in System Settings\n- Fastfetch - system information\n- Calamares - system installer\n\nOrkaLinux is made by one person, _inc0gnit0. If something doesn't work or you\nhave an idea, message me on Discord, happy to chat.\n\nProject website:\nhttps://cyzs-retroweb.rf.gd/orkalinux.php\n\nDiscord:\nhttps://discord.gg/JkC9P6ebN2\n\nYouTube:\nhttps://www.youtube.com/@_inc0gnit0",
        "release_text": "OrkaLinux B3 (Undertow)\n\nHey! Here's what changed since B2:\n\n- new look, dark or light (switch at the bottom of this window), the wallpaper follows it\n- a bunch of new wallpapers, including EC-2 photos\n- window animations (yes, the wobbly windows are on purpose)\n- new terminal: kitty, see-through, blurred, with a cursor trail and a colourful prompt\n- Firefox straight from Mozilla, always the latest one\n- newer kernel, works better on new hardware\n- Flathub in Discover, so way more apps\n- Steam, OBS, GIMP and more in one click (Extra apps)\n- NVIDIA drivers can be installed from Hello\n- printing works\n- Discord updates itself\n- the system is in English by default, pick another language in the installer\n\nIt's still a beta, so stuff can break. If something doesn't work, tell me on Discord:\nhttps://discord.gg/JkC9P6ebN2\n\nThanks for testing!",
    },
    "de": {
        "title": "Willkommen bei OrkaLinux!",
        "subtitle": "B3 (Undertow) · by _inc0gnit0",
        "welcome_text_live": "Danke, dass Sie OrkaLinux gewählt haben! Es basiert auf Debian 13 (Trixie) mit dem KDE Plasma Desktop. Sie können es ohne Installation testen oder direkt installieren.",
        "welcome_text_installed": "Danke für die Installation von OrkaLinux! Schön, dass Sie dabei sind – ich hoffe, Sie bleiben lange. _inc0gnit0",
        "btn_readme": "Readme", "desc_readme": "Was enthalten ist",
        "btn_release": "Versionshinweise", "desc_release": "Neu in B3",
        "btn_site": "Projektseite", "desc_site": "Downloads und News",
        "btn_discord": "Discord", "desc_discord": "Mit der Community chatten",
        "btn_youtube": "YouTube", "desc_youtube": "Videos und Anleitungen",
        "btn_apps": "Anwendungen", "desc_apps": "Software-Store",
        "btn_extras": "Weitere Programme", "desc_extras": "Steam, OBS, GIMP und mehr",
        "btn_nvidia": "NVIDIA-Treiber", "desc_nvidia": "Volle Grafikleistung",
        "btn_look": "OrkaLinux Aussehen", "desc_look": "Layout, Farben, Hintergrund, Effekte",
        "btn_center": "OrkaLinux Zentrum", "desc_center": "Treiber, Kernel, Aufräumen",
        "btn_backup": "OrkaLinux Sicherung", "desc_backup": "Wiederherstellungspunkte",
        "extras_count": "Ausgewählt: {n}",
        "btn_install": "OrkaLinux installieren",
        "autostart": "Beim Start ausführen",
        "dark_mode": "Dunkler Modus",
        "close": "Schließen",
        "cancel": "Abbrechen",
        "extras_title": "Weitere Programme",
        "extras_intro": "Wählen Sie die Programme aus, die Sie installieren möchten. Sie kommen von Flathub und werden mit dem restlichen System aktualisiert (Discover).",
        "extras_install": "Auswahl installieren",
        "installed": "installiert",
        "cat_games": "Spiele", "cat_create": "Kreativ", "cat_internet": "Internet und Musik", "cat_dev": "Arbeit und mehr", "cat_ai": "KI",
        "nvidia_title": "NVIDIA-Treiber installieren?",
        "nvidia_text": "OrkaLinux installiert den offiziellen NVIDIA-Treiber aus dem Debian-Repository (ca. 500 MB Download). Sie werden nach Ihrem Passwort gefragt und müssen den Computer am Ende neu starten.\n\nWenn Secure Boot aktiv ist, legen Sie ein Einmal-Passwort fest, um den Treiber nach dem Neustart zu bestätigen – das Installationsfenster erklärt jeden Schritt.",
        "nvidia_go": "Installieren",
        "term_done": "Fertig! Das Fenster schließt sich gleich.",
        "term_failed": "Etwas ist schiefgelaufen – machen Sie einen Screenshot und schicken Sie ihn mir im OrkaLinux-Discord. Enter schließt das Fenster.",
        "no_terminal": "Das Terminal konnte nicht geöffnet werden.",
        "readme_text": "OrkaLinux B3 (Undertow)\n================================\n\nOrkaLinux ist eine Linux-Distribution basierend auf Debian 13\nmit dem KDE Plasma Desktop.\n\nOrkaLinux wird von einer Person gemacht: _inc0gnit0. Wenn etwas nicht klappt\noder Sie eine Idee haben, schreiben Sie mir auf Discord.\n\nProjektseite:\nhttps://cyzs-retroweb.rf.gd/orkalinux.php\n\nDiscord:\nhttps://discord.gg/JkC9P6ebN2",
        "release_text": "OrkaLinux B3 (Undertow)\n\nHi! Das ist neu seit B2:\n\n- neues Design, dunkel oder hell (Schalter unten in diesem Fenster), das Hintergrundbild passt sich an\n- viele neue Hintergrundbilder\n- Fensteranimationen\n- neues Terminal: kitty, durchsichtig, mit Unschärfe und Cursor-Spur\n- Firefox direkt von Mozilla, immer die neueste Version\n- neuerer Kernel für neue Hardware\n- Flathub in Discover\n- Steam, OBS, GIMP und mehr mit einem Klick\n- NVIDIA-Treiber direkt aus Hello\n- Drucken funktioniert\n- Discord aktualisiert sich selbst\n\nIst noch eine Beta, also kann etwas kaputtgehen. Probleme bitte auf Discord melden:\nhttps://discord.gg/JkC9P6ebN2\n\nDanke fürs Testen!",
    },
    "fr": {
        "title": "Bienvenue sur OrkaLinux!",
        "subtitle": "B3 (Undertow) · by _inc0gnit0",
        "welcome_text_live": "Merci d'avoir choisi OrkaLinux! Il est basé sur Debian 13 (Trixie) avec le bureau KDE Plasma. Essayez-le sans installation ou installez-le directement.",
        "welcome_text_installed": "Merci d'avoir installé OrkaLinux ! Ravi que vous fassiez partie de la communauté – j'espère que vous resterez longtemps. _inc0gnit0",
        "btn_readme": "Lisez-moi", "desc_readme": "Ce qui est inclus",
        "btn_release": "Notes de version", "desc_release": "Nouveautés de B3",
        "btn_site": "Site du projet", "desc_site": "Téléchargements et actus",
        "btn_discord": "Discord", "desc_discord": "Discuter avec la communauté",
        "btn_youtube": "YouTube", "desc_youtube": "Vidéos et tutoriels",
        "btn_apps": "Applications", "desc_apps": "Logithèque",
        "btn_extras": "Plus de logiciels", "desc_extras": "Steam, OBS, GIMP et plus",
        "btn_nvidia": "Pilotes NVIDIA", "desc_nvidia": "Toute la puissance graphique",
        "btn_look": "Apparence OrkaLinux", "desc_look": "Disposition, couleurs, fond, effets",
        "btn_center": "Centre OrkaLinux", "desc_center": "Pilotes, noyau, nettoyage",
        "btn_backup": "Sauvegarde OrkaLinux", "desc_backup": "Points de restauration",
        "extras_count": "Sélection : {n}",
        "btn_install": "Installer OrkaLinux",
        "autostart": "Lancer au démarrage",
        "dark_mode": "Mode sombre",
        "close": "Fermer",
        "cancel": "Annuler",
        "extras_title": "Plus de logiciels",
        "extras_intro": "Cochez les logiciels à installer. Ils viennent de Flathub et se mettent à jour avec le reste du système (Discover).",
        "extras_install": "Installer la sélection",
        "installed": "installé",
        "cat_games": "Jeux", "cat_create": "Création", "cat_internet": "Internet et musique", "cat_dev": "Travail et plus", "cat_ai": "IA",
        "nvidia_title": "Installer le pilote NVIDIA ?",
        "nvidia_text": "OrkaLinux va installer le pilote NVIDIA officiel depuis le dépôt Debian (environ 500 Mo à télécharger). Votre mot de passe sera demandé et il faudra redémarrer l'ordinateur à la fin.\n\nSi Secure Boot est activé, vous choisirez un mot de passe temporaire pour valider le pilote après le redémarrage – la fenêtre d'installation explique chaque étape.",
        "nvidia_go": "Installer",
        "term_done": "Terminé ! La fenêtre va se fermer.",
        "term_failed": "Une erreur s'est produite – faites une capture de cette fenêtre et envoyez-la-moi sur le Discord OrkaLinux. Entrée ferme la fenêtre.",
        "no_terminal": "Impossible d'ouvrir le terminal.",
        "readme_text": "OrkaLinux B3 (Undertow)\n================================\n\nOrkaLinux est une distribution Linux basée sur Debian 13\navec le bureau KDE Plasma.\n\nOrkaLinux est fait par une seule personne, _inc0gnit0. Si quelque chose ne marche\npas ou si vous avez une idée, écrivez-moi sur Discord.\n\nSite du projet:\nhttps://cyzs-retroweb.rf.gd/orkalinux.php\n\nDiscord:\nhttps://discord.gg/JkC9P6ebN2",
        "release_text": "OrkaLinux B3 (Undertow)\n\nSalut ! Voici ce qui a changé depuis B2 :\n\n- nouveau look, sombre ou clair (bouton en bas de cette fenêtre), le fond d'écran suit\n- plein de nouveaux fonds d'écran\n- animations des fenêtres\n- nouveau terminal : kitty, transparent, avec flou et traînée du curseur\n- Firefox directement de Mozilla, toujours à jour\n- noyau plus récent pour le matériel récent\n- Flathub dans Discover\n- Steam, OBS, GIMP et plus en un clic\n- pilotes NVIDIA depuis Hello\n- l'impression fonctionne\n- Discord se met à jour tout seul\n\nC'est encore une bêta, donc des bugs sont possibles. Signale-les sur Discord :\nhttps://discord.gg/JkC9P6ebN2\n\nMerci de tester !",
    },
}

LANG_NAMES = {
    "pl": "Polski",
    "en": "English",
    "de": "Deutsch",
    "fr": "Français",
}

# Dodatkowe programy z Flathuba. Lista leży w JSON-ie, bo z tego samego pliku
# hook 0250 bierze ID programów, żeby przy budowaniu ISO ściągnąć ich ikony.
EXTRAS_FILE = "/usr/share/orkalinux/extras.json"
EXTRAS_ICONS = "/usr/share/orkalinux/extras-icons"
ORKA_APPS = "/usr/share/{0}/{0}.py"


EXTRAS_SCRIPTS = "/usr/share/orkalinux/extras"


def load_extras():
    try:
        with open(EXTRAS_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


# Fale w nagłówku w kolorach tapety Undertow: granat u góry, niżej coraz bardziej
# fioletowy błękit, na grzbietach cienkie jasne linie.
# (wysokość fali, długość, prędkość, poziom, kolor RGB, krycie)
WAVES = [
    (10.0, 150.0, 0.45, 0.56, (0.055, 0.070, 0.420), 0.80),
    (13.0, 220.0, -0.30, 0.70, (0.115, 0.086, 0.660), 0.85),
    (8.0, 105.0, 0.70, 0.84, (0.205, 0.122, 0.790), 0.92),
]

CSS = b"""
window.orka { background-color: #070b26; }

.hero-title { color: #ffffff; font-size: 26px; font-weight: 800; }
.hero-sub { color: rgba(255, 255, 255, 0.70); font-size: 12px; }

.welcome { color: #c9d1ff; font-size: 13px; }

button.card {
    background-image: none;
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 14px;
    padding: 12px 14px;
    box-shadow: none;
    text-shadow: none;
    -gtk-icon-shadow: none;
    transition: all 220ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
button.card:hover {
    background-color: rgba(90, 110, 255, 0.18);
    border-color: rgba(140, 155, 255, 0.60);
    box-shadow: 0 6px 18px rgba(20, 30, 160, 0.45);
}
button.card:active { background-color: rgba(90, 110, 255, 0.32); }
button.card image {
    -gtk-icon-transform: scale(1);
    transition: -gtk-icon-transform 220ms ease-out;
}
button.card:hover image { -gtk-icon-transform: scale(1.18); }
.card-title { color: #ffffff; font-weight: bold; font-size: 14px; }
.card-desc { color: rgba(255, 255, 255, 0.60); font-size: 11px; }

button.install {
    background-image: linear-gradient(90deg, #2b3bff, #6a2bff);
    color: #ffffff;
    border: none;
    border-radius: 14px;
    padding: 12px 34px;
    font-size: 15px;
    font-weight: bold;
    text-shadow: none;
    box-shadow: 0 4px 14px rgba(60, 70, 255, 0.35);
    transition: all 250ms ease-out;
}
button.install label { color: #ffffff; }
button.install:hover {
    background-image: linear-gradient(90deg, #4050ff, #7d45ff);
    box-shadow: 0 8px 28px rgba(100, 110, 255, 0.70);
}

button.primary {
    background-image: linear-gradient(90deg, #2b3bff, #6a2bff);
    border: none;
    border-radius: 10px;
    padding: 6px 20px;
    text-shadow: none;
    box-shadow: none;
}
button.primary label { color: #ffffff; font-weight: bold; }
button.primary:hover { background-image: linear-gradient(90deg, #4050ff, #7d45ff); }
button.primary:disabled { background-image: none; background-color: rgba(255, 255, 255, 0.08); }
button.primary:disabled label { color: rgba(255, 255, 255, 0.35); }

.footer { background-color: #050820; border-top: 1px solid rgba(255, 255, 255, 0.08); }
.footer label { color: rgba(255, 255, 255, 0.75); }
switch { border-radius: 14px; background-image: none; background-color: rgba(255, 255, 255, 0.15); border: none; transition: all 200ms ease-out; }
switch:checked { background-color: #3b4bff; }
switch slider { border-radius: 14px; background-image: none; background-color: #ffffff; border: none; box-shadow: none; }

button.ghost {
    background-image: none;
    background-color: rgba(255, 255, 255, 0.08);
    color: #ffffff;
    border: 1px solid rgba(255, 255, 255, 0.10);
    border-radius: 10px;
    padding: 6px 20px;
    text-shadow: none;
    box-shadow: none;
    transition: all 200ms ease-out;
}
button.ghost label { color: #ffffff; }
button.ghost:hover { background-color: rgba(255, 255, 255, 0.16); }

combobox button {
    background-image: none;
    background-color: rgba(255, 255, 255, 0.10);
    color: #ffffff;
    border: 1px solid rgba(255, 255, 255, 0.20);
    border-radius: 10px;
    text-shadow: none;
    box-shadow: none;
}
combobox button label, combobox arrow { color: #ffffff; }

.doc-title { color: #ffffff; font-size: 20px; font-weight: 800; }
scrolledwindow.doc {
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 14px;
}
scrolledwindow.doc viewport { background-color: transparent; }
.doc-text { color: #dfe4ff; font-size: 13px; }
dialog.orka, dialog.orka box, dialog.orka scrolledwindow, dialog.orka viewport { background-color: #0b1033; }
dialog.orka label { color: #e3e7ff; font-family: monospace; }

dialog.picker, dialog.picker box, dialog.picker scrolledwindow, dialog.picker viewport { background-color: #0b1033; }
dialog.picker label { color: #e3e7ff; }
.picker-intro { color: #c9d1ff; font-size: 13px; }
.picker-cat { color: #8f9cff; font-weight: bold; font-size: 13px; }
.picker-name { color: #ffffff; font-weight: bold; }
.picker-desc { color: rgba(255, 255, 255, 0.55); font-size: 11px; }
.picker-count { color: #c9d1ff; font-weight: bold; }

button.app-tile {
    background-image: none;
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    padding: 14px 8px 12px 8px;
    box-shadow: none;
    text-shadow: none;
    transition: all 180ms ease-out;
}
button.app-tile:hover { background-color: rgba(90, 110, 255, 0.14); border-color: rgba(140, 155, 255, 0.45); }
button.app-tile:checked {
    background-color: rgba(79, 88, 240, 0.30);
    border-color: #8a93ff;
    box-shadow: 0 0 0 1px #8a93ff, 0 6px 18px rgba(40, 50, 200, 0.45);
}
button.app-tile:disabled { background-color: rgba(255, 255, 255, 0.03); border-color: rgba(255, 255, 255, 0.05); }
button.app-tile:disabled .picker-name { color: rgba(255, 255, 255, 0.55); }
.tile-mark { background-color: #4f58f0; color: #ffffff; border-radius: 11px; font-weight: bold; font-size: 11px; padding: 1px 6px; }
.tile-done { background-color: rgba(61, 220, 151, 0.20); color: #3ddc97; border-radius: 9px; font-size: 10px; font-weight: bold; padding: 1px 7px; }
flowboxchild { padding: 0; background: none; }
.extras-bar { margin-top: 6px; }
"""


# Jasny wygląd Hello (gdy system ma jasny motyw). Nagłówek z falami zostaje granatowy.
LIGHT_CSS = b"""
window.orka { background-color: #f3f5fc; }
.welcome { color: #3a4170; }
button.card { background-color: #ffffff; border-color: rgba(30, 40, 120, 0.12); }
button.card:hover { background-color: #eef0ff; border-color: #8a93ff; box-shadow: 0 6px 18px rgba(60, 70, 200, 0.18); }
button.card:active { background-color: #e2e5ff; }
.card-title { color: #161a36; }
.card-desc { color: rgba(22, 26, 54, 0.60); }

button.primary:disabled { background-color: rgba(20, 30, 90, 0.10); }
button.primary:disabled label { color: rgba(22, 26, 54, 0.40); }
button.ghost { background-color: rgba(30, 40, 120, 0.06); border-color: rgba(30, 40, 120, 0.14); color: #161a36; }
button.ghost label, button.ghost image { color: #161a36; }
button.ghost:hover { background-color: rgba(30, 40, 120, 0.12); }

.footer { background-color: #e8ebf8; border-top-color: rgba(20, 30, 90, 0.10); }
.footer label { color: rgba(22, 26, 54, 0.80); }
switch { background-color: rgba(20, 30, 90, 0.18); }
switch:checked { background-color: #3b4bff; }

.doc-title { color: #161a36; }
scrolledwindow.doc { background-color: #ffffff; border-color: rgba(30, 40, 120, 0.12); }
.doc-text { color: #252a4a; }

.picker-intro, .picker-count { color: #3a4170; }
.picker-cat { color: #3b46d6; }
.picker-name { color: #161a36; }
.picker-desc { color: rgba(22, 26, 54, 0.60); }
button.app-tile { background-color: #ffffff; border-color: rgba(30, 40, 120, 0.12); }
button.app-tile:hover { background-color: #eef0ff; border-color: rgba(108, 120, 255, 0.60); }
button.app-tile:checked { background-color: rgba(79, 88, 240, 0.12); border-color: #6c78ff; box-shadow: 0 0 0 1px #6c78ff; }
button.app-tile:disabled { background-color: rgba(255, 255, 255, 0.60); border-color: rgba(30, 40, 120, 0.06); }
button.app-tile:disabled .picker-name { color: rgba(22, 26, 54, 0.50); }
.tile-done { background-color: rgba(19, 138, 90, 0.12); color: #138a5a; }
"""


def first_icon(names):
    theme = Gtk.IconTheme.get_default()
    for name in names:
        if theme.has_icon(name):
            return name
    return names[-1]


def system_lang():
    """Język Hello taki jak systemu, a jak go nie ma albo nie znamy – angielski."""
    for var in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG"):
        value = os.environ.get(var, "")
        if value and value not in ("C", "POSIX"):
            code = value.split(":")[0][:2]
            return code if code in TRANSLATIONS else "en"
    return "en"


def has_nvidia_gpu():
    for dev in glob.glob("/sys/bus/pci/devices/*"):
        try:
            with open(dev + "/vendor") as f:
                vendor = f.read().strip()
            with open(dev + "/class") as f:
                pci_class = f.read().strip()
        except OSError:
            continue
        if vendor == "0x10de" and pci_class.startswith("0x03"):
            return True
    return False


def package_installed(name):
    try:
        out = subprocess.run(["dpkg-query", "-W", "-f=${Status}", name],
                             capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return False
    return out.strip().endswith("installed") and "not-installed" not in out


def installed_flatpaks():
    try:
        out = subprocess.run(["flatpak", "list", "--app", "--columns=application"],
                             capture_output=True, text=True, timeout=30).stdout
    except (OSError, subprocess.SubprocessError):
        return set()
    return set(out.split())


def is_dark_mode():
    """Czy Plasma ma teraz ciemny motyw – po jasności tła okien w bieżącym schemacie."""
    for path in (os.path.expanduser("~/.config/kdeglobals"), "/etc/xdg/kdeglobals"):
        try:
            with open(path, encoding="utf-8") as f:
                group = None
                for line in f:
                    line = line.strip()
                    if line.startswith("["):
                        group = line
                    elif group == "[Colors:Window]" and line.startswith("BackgroundNormal="):
                        r, g, b = (int(v) for v in line.split("=", 1)[1].split(",")[:3])
                        return 0.2126 * r + 0.7152 * g + 0.0722 * b < 128
        except (OSError, ValueError):
            continue
    return True  # domyślny wygląd OrkaLinux jest ciemny


def set_gtk_dark(dark):
    """Programy GTK (np. Firefox) w tym samym trybie co Plasma – dla nowo otwieranych okien."""
    for version in ("gtk-3.0", "gtk-4.0"):
        path = os.path.expanduser(f"~/.config/{version}/settings.ini")
        config = configparser.ConfigParser(interpolation=None)
        config.optionxform = str
        try:
            config.read(path, encoding="utf-8")
        except configparser.Error:
            continue
        if not config.has_section("Settings"):
            config.add_section("Settings")
        config["Settings"]["gtk-theme-name"] = "Breeze-Dark" if dark else "Breeze"
        config["Settings"]["gtk-application-prefer-dark-theme"] = "true" if dark else "false"
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            config.write(f, space_around_delimiters=False)


def build_cards():
    """Kafelki: (klucz tekstu, ikony do wyboru – pierwsza istniejąca wygrywa, akcja)."""
    cards = [
        ("readme", ["help-about", "dialog-information"], "dialog:readme_text"),
        ("release", ["text-x-changelog", "text-x-generic"], "dialog:release_text"),
        ("site", ["internet-web-browser", "applications-internet"], SITE_URL),
        ("discord", ["discord", "applications-internet"], DISCORD_URL),
        ("youtube", ["orka-youtube", "youtube", "applications-multimedia", "video-x-generic"], YOUTUBE_URL),
        ("apps", ["plasmadiscover", "system-software-install", "applications-other"], "plasma-discover"),
        ("look", ["orka-wyglad", "preferences-desktop-theme"], ORKA_APPS.format("orka-wyglad")),
        ("center", ["orka-centrum", "preferences-system"], ORKA_APPS.format("orka-centrum")),
    ]
    # W live instalowanie programów i kopie nie mają sensu – wszystko znika po restarcie
    if not IS_LIVE:
        cards.append(("backup", ["orka-kopia", "document-revert"], ORKA_APPS.format("orka-kopia")))
        cards.append(("extras", ["applications-games", "package-x-generic", "applications-other"], "extras:"))
        if has_nvidia_gpu() and not package_installed("nvidia-driver"):
            cards.append(("nvidia", ["nvidia", "video-display", "preferences-desktop-display"],
                          ORKA_APPS.format("orka-centrum") + " drivers"))
    return cards


class Waves(Gtk.DrawingArea):
    """Animowany nagłówek: granatowy gradient i fale, jak na tapecie OrkaLinux."""

    def __init__(self):
        super().__init__()
        self.t = 0.0
        self.add_tick_callback(self.on_tick)
        self.connect("draw", self.on_draw)

    def on_tick(self, widget, clock):
        self.t = clock.get_frame_time() / 1_000_000
        self.queue_draw()
        return GLib.SOURCE_CONTINUE

    def on_draw(self, widget, cr):
        import cairo
        w = self.get_allocated_width()
        h = self.get_allocated_height()
        bg = cairo.LinearGradient(0, 0, 0, h)
        bg.add_color_stop_rgb(0, 0.016, 0.020, 0.118)
        bg.add_color_stop_rgb(0.6, 0.043, 0.059, 0.227)
        bg.add_color_stop_rgb(1, 0.059, 0.071, 0.420)
        cr.set_source(bg)
        cr.paint()
        for i, (amp, length, speed, level, color, alpha) in enumerate(WAVES):
            points = []
            x = 0.0
            while x <= w + 8:
                points.append((x, h * level + amp * math.sin(x / length + self.t * speed + i * 1.7)))
                x += 6
            cr.move_to(0, h)
            for px, py in points:
                cr.line_to(px, py)
            cr.line_to(w, h)
            cr.close_path()
            cr.set_source_rgba(*color, alpha)
            cr.fill()
            # jasna linia na grzbiecie fali, jak na tapecie
            cr.move_to(*points[0])
            for px, py in points[1:]:
                cr.line_to(px, py)
            cr.set_source_rgba(0.80, 0.82, 1.0, 0.22 + 0.10 * i)
            cr.set_line_width(1.2)
            cr.stroke()
        return False


class OrkaLinuxHello(Gtk.Window):
    def __init__(self):
        super().__init__()
        self.lang = system_lang()
        self.tr = TRANSLATIONS[self.lang]
        self.cards = build_cards()
        self.set_title(self.tr["title"])
        self.set_icon_name("orka-hello")
        self.set_default_size(1120 if len(self.cards) > 6 else 860, -1)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_resizable(False)
        self.get_style_context().add_class("orka")

        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)
        self.light = None
        self.set_light(not is_dark_mode())

        self.root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(self.root)
        self.build_ui()

    def set_light(self, on):
        """Jasne albo ciemne kolory okna, od razu, bez ponownego otwierania."""
        screen = Gdk.Screen.get_default()
        if on and self.light is None:
            self.light = Gtk.CssProvider()
            self.light.load_from_data(LIGHT_CSS)
            Gtk.StyleContext.add_provider_for_screen(screen, self.light, Gtk.STYLE_PROVIDER_PRIORITY_USER + 1)
        elif not on and self.light is not None:
            Gtk.StyleContext.remove_provider_for_screen(screen, self.light)
            self.light = None

    # ---------- budowanie okna ----------

    def build_ui(self):
        for child in self.root.get_children():
            self.root.remove(child)
        self.reveals = []

        self.root.pack_start(self.build_hero(), False, False, 0)

        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        body.set_margin_top(22)
        body.set_margin_bottom(22)
        body.set_margin_start(28)
        body.set_margin_end(28)
        # Strona główna i strona z tekstem (Readme, Info o wydaniu) w jednym oknie
        self.pages = Gtk.Stack()
        self.pages.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.pages.set_transition_duration(250)
        self.pages.set_homogeneous(True)
        self.pages.add_named(body, "home")
        self.pages.add_named(self.build_text_page(), "text")
        self.root.pack_start(self.pages, True, True, 0)

        welcome = Gtk.Label(label=self.tr["welcome_text_live" if IS_LIVE else "welcome_text_installed"])
        welcome.set_line_wrap(True)
        welcome.set_max_width_chars(90)
        welcome.set_xalign(0)
        welcome.get_style_context().add_class("welcome")
        body.pack_start(self.animated(welcome), False, False, 0)

        columns = 4 if len(self.cards) > 6 else 3
        grid = Gtk.Grid(column_spacing=12, row_spacing=12, column_homogeneous=True)
        for i, (key, icons, action) in enumerate(self.cards):
            grid.attach(self.animated(self.build_card(key, icons, action)), i % columns, i // columns, 1, 1)
        body.pack_start(grid, False, False, 0)

        if IS_LIVE:
            install = Gtk.Button()
            install.get_style_context().add_class("install")
            box = Gtk.Box(spacing=12)
            try:
                pix = GdkPixbuf.Pixbuf.new_from_file_at_scale(LOGO_WHITE, 26, 26, True)
                box.pack_start(Gtk.Image.new_from_pixbuf(pix), False, False, 0)
            except GLib.Error:
                pass
            box.pack_start(Gtk.Label(label=self.tr["btn_install"]), False, False, 0)
            install.add(box)
            install.set_halign(Gtk.Align.CENTER)
            install.connect("clicked", self.on_action, "orka-install")
            body.pack_start(self.animated(install), False, False, 4)

        self.root.pack_end(self.build_footer(), False, False, 0)
        self.show_all()
        self.start_animation()

    def build_hero(self):
        overlay = Gtk.Overlay()
        waves = Waves()
        waves.set_size_request(-1, 170)
        overlay.add(waves)

        row = Gtk.Box(spacing=20)
        row.set_margin_start(32)
        row.set_margin_end(24)
        row.set_margin_top(20)
        row.set_margin_bottom(28)
        try:
            pix = GdkPixbuf.Pixbuf.new_from_file_at_scale(LOGO_WHITE, 96, 96, True)
            row.pack_start(Gtk.Image.new_from_pixbuf(pix), False, False, 0)
        except GLib.Error:
            row.pack_start(Gtk.Image.new_from_icon_name("orkalinux", Gtk.IconSize.DIALOG), False, False, 0)

        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        texts.set_valign(Gtk.Align.CENTER)
        title = Gtk.Label(label=self.tr["title"], xalign=0)
        title.get_style_context().add_class("hero-title")
        sub = Gtk.Label(label="OrkaLinux " + self.tr["subtitle"], xalign=0)
        sub.get_style_context().add_class("hero-sub")
        texts.pack_start(title, False, False, 0)
        texts.pack_start(sub, False, False, 0)
        row.pack_start(texts, True, True, 0)

        # Wybór języka tylko w live. Po instalacji język jest już wybrany
        # w instalatorze i Hello po prostu go używa.
        if IS_LIVE:
            lang = Gtk.ComboBoxText()
            for code, name in LANG_NAMES.items():
                lang.append(code, name)
            lang.set_active_id(self.lang)
            lang.set_valign(Gtk.Align.START)
            lang.connect("changed", self.on_lang_changed)
            row.pack_end(lang, False, False, 0)

        overlay.add_overlay(self.animated(row))
        return overlay

    def build_card(self, key, icons, action):
        button = Gtk.Button()
        button.get_style_context().add_class("card")
        box = Gtk.Box(spacing=12)
        if key == "discord" and os.path.exists("/usr/share/pixmaps/discord.png"):
            pix = GdkPixbuf.Pixbuf.new_from_file_at_scale("/usr/share/pixmaps/discord.png", 32, 32, True)
            icon = Gtk.Image.new_from_pixbuf(pix)
        else:
            icon = Gtk.Image.new_from_icon_name(first_icon(icons), Gtk.IconSize.DND)
            icon.set_pixel_size(32)
        box.pack_start(icon, False, False, 0)

        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title = Gtk.Label(label=self.tr["btn_" + key], xalign=0)
        title.get_style_context().add_class("card-title")
        desc = Gtk.Label(label=self.tr["desc_" + key], xalign=0)
        desc.get_style_context().add_class("card-desc")
        texts.pack_start(title, False, False, 0)
        texts.pack_start(desc, False, False, 0)
        box.pack_start(texts, True, True, 0)

        button.add(box)
        button.connect("clicked", self.on_action, action)
        return button

    def build_footer(self):
        footer = Gtk.Box(spacing=10)
        footer.get_style_context().add_class("footer")
        inner = Gtk.Box(spacing=10)
        inner.set_margin_start(28)
        inner.set_margin_end(20)
        inner.set_margin_top(10)
        inner.set_margin_bottom(10)

        switch = Gtk.Switch()
        switch.set_active(os.path.exists(AUTOSTART_FILE))
        switch.set_valign(Gtk.Align.CENTER)
        switch.connect("notify::active", self.on_autostart_toggled)
        inner.pack_start(switch, False, False, 0)
        inner.pack_start(Gtk.Label(label=self.tr["autostart"]), False, False, 0)

        # Jasny/ciemny wygląd całego systemu (tapeta Undertow zmienia się razem z nim)
        dark = Gtk.Switch()
        dark.set_active(is_dark_mode())
        dark.set_valign(Gtk.Align.CENTER)
        dark.set_margin_start(24)
        dark.connect("notify::active", self.on_dark_toggled)
        inner.pack_start(dark, False, False, 0)
        inner.pack_start(Gtk.Label(label=self.tr["dark_mode"]), False, False, 0)

        close = Gtk.Button(label=self.tr["close"])
        close.get_style_context().add_class("ghost")
        close.connect("clicked", lambda *_: Gtk.main_quit())
        inner.pack_end(close, False, False, 0)

        footer.pack_start(inner, True, True, 0)
        return footer

    # ---------- animacje ----------

    def animated(self, widget):
        """Opakowuje element tak, żeby płynnie się pojawił po otwarciu okna."""
        revealer = Gtk.Revealer()
        revealer.set_transition_type(Gtk.RevealerTransitionType.CROSSFADE)
        revealer.set_transition_duration(450)
        revealer.add(widget)
        self.reveals.append(revealer)
        return revealer

    def start_animation(self):
        for i, revealer in enumerate(self.reveals):
            GLib.timeout_add(80 + i * 70, self.reveal, revealer)

    @staticmethod
    def reveal(revealer):
        revealer.set_reveal_child(True)
        return GLib.SOURCE_REMOVE

    # ---------- akcje ----------

    def on_action(self, widget, action):
        if action.startswith("dialog:"):
            self.show_text_dialog(action.split(":", 1)[1])
        elif action == "extras:":
            self.show_extras()
        elif action.startswith("http"):
            subprocess.Popen(["xdg-open", action])
        else:
            subprocess.Popen(shlex.split(action))

    def build_text_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        page.set_margin_top(18)
        page.set_margin_bottom(18)
        page.set_margin_start(28)
        page.set_margin_end(28)
        top = Gtk.Box(spacing=12)
        back = Gtk.Button()
        back.get_style_context().add_class("ghost")
        back.add(Gtk.Image.new_from_icon_name("go-previous-symbolic", Gtk.IconSize.BUTTON))
        back.connect("clicked", lambda *_: self.pages.set_visible_child_name("home"))
        top.pack_start(back, False, False, 0)
        self.text_icon = Gtk.Image()
        top.pack_start(self.text_icon, False, False, 0)
        self.text_title = Gtk.Label(xalign=0)
        self.text_title.get_style_context().add_class("doc-title")
        top.pack_start(self.text_title, True, True, 0)
        page.pack_start(top, False, False, 0)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(300)
        scrolled.get_style_context().add_class("doc")
        self.text_body = Gtk.Label(xalign=0, yalign=0, selectable=True)
        self.text_body.set_line_wrap(True)
        self.text_body.set_max_width_chars(110)
        self.text_body.get_style_context().add_class("doc-text")
        self.text_body.set_margin_top(18)
        self.text_body.set_margin_bottom(18)
        self.text_body.set_margin_start(22)
        self.text_body.set_margin_end(22)
        scrolled.add(self.text_body)
        page.pack_start(scrolled, True, True, 0)
        return page

    def show_text_dialog(self, text_key):
        """Readme albo Info o wydaniu: tekst wjeżdża w miejsce kafelków, strzałka wraca."""
        readme = text_key == "readme_text"
        self.text_title.set_text(self.tr["btn_readme" if readme else "btn_release"])
        icons = ["help-about", "dialog-information"] if readme else ["text-x-changelog", "text-x-generic"]
        self.text_icon.set_from_icon_name(first_icon(icons), Gtk.IconSize.DND)
        self.text_icon.set_pixel_size(28)
        self.text_body.set_text(self.tr[text_key])
        self.pages.show_all()
        self.pages.set_visible_child_name("text")

    def extras_icon(self, app_id, name):
        """Ikona z Flathuba (ściągnięta przy budowaniu ISO), a jak jej nie ma – kafelek z literą."""
        path = os.path.join(EXTRAS_ICONS, app_id + ".png")
        if os.path.exists(path):
            try:
                pix = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 56, 56, True)
                return Gtk.Image.new_from_pixbuf(pix)
            except GLib.Error:
                pass
        area = Gtk.DrawingArea()
        area.set_size_request(56, 56)
        hue = sum(map(ord, app_id)) % 360 / 360.0

        def draw(widget, cr):
            import cairo
            import colorsys
            r, g, b = colorsys.hsv_to_rgb(hue, 0.55, 0.95)
            grad = cairo.LinearGradient(0, 0, 56, 56)
            grad.add_color_stop_rgb(0, r, g, b)
            grad.add_color_stop_rgb(1, r * 0.45, g * 0.45, b * 0.75)
            radius = 14
            cr.new_sub_path()
            cr.arc(56 - radius, radius, radius, -math.pi / 2, 0)
            cr.arc(56 - radius, 56 - radius, radius, 0, math.pi / 2)
            cr.arc(radius, 56 - radius, radius, math.pi / 2, math.pi)
            cr.arc(radius, radius, radius, math.pi, 3 * math.pi / 2)
            cr.close_path()
            cr.set_source(grad)
            cr.fill()
            cr.set_source_rgb(1, 1, 1)
            cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            cr.set_font_size(28)
            ext = cr.text_extents(name[0])
            cr.move_to(28 - ext.width / 2 - ext.x_bearing, 28 - ext.height / 2 - ext.y_bearing)
            cr.show_text(name[0])
            return False
        area.connect("draw", draw)
        return area

    def extras_tile(self, app, installed):
        tile = Gtk.ToggleButton()
        tile.get_style_context().add_class("app-tile")
        tile.set_size_request(150, 150)
        overlay = Gtk.Overlay()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        icon = self.extras_icon(app["id"], app["name"])
        icon.set_halign(Gtk.Align.CENTER)
        box.pack_start(icon, False, False, 2)
        name = Gtk.Label(label=app["name"])
        name.get_style_context().add_class("picker-name")
        name.set_ellipsize(3)  # Pango.EllipsizeMode.END
        name.set_max_width_chars(16)
        box.pack_start(name, False, False, 0)
        desc = Gtk.Label(label=app.get(self.lang, app["en"]))
        desc.get_style_context().add_class("picker-desc")
        desc.set_line_wrap(True)
        desc.set_justify(Gtk.Justification.CENTER)
        desc.set_max_width_chars(18)
        box.pack_start(desc, False, False, 0)
        overlay.add(box)

        mark = Gtk.Label(label=self.tr["installed"] if installed else "\u2713")
        mark.get_style_context().add_class("tile-done" if installed else "tile-mark")
        mark.set_halign(Gtk.Align.END)
        mark.set_valign(Gtk.Align.START)
        mark.set_no_show_all(True)
        overlay.add_overlay(mark)
        tile.add(overlay)

        if installed:
            tile.set_sensitive(False)
            mark.show()
        else:
            tile.connect("toggled", lambda t: mark.set_visible(t.get_active()))
        return tile

    def show_extras(self):
        """Kafelki z programami z Flathuba do zaznaczenia; instalacja w terminalu.
        Strona wjeżdża w oknie Hello (jak Readme), strzałka wraca."""
        installed = installed_flatpaks()
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.set_margin_top(18)
        page.set_margin_bottom(16)
        page.set_margin_start(28)
        page.set_margin_end(28)

        top = Gtk.Box(spacing=12)
        back = Gtk.Button()
        back.get_style_context().add_class("ghost")
        back.add(Gtk.Image.new_from_icon_name("go-previous-symbolic", Gtk.IconSize.BUTTON))
        back.connect("clicked", lambda *_: self.close_extras())
        top.pack_start(back, False, False, 0)
        icon = Gtk.Image.new_from_icon_name(first_icon(["applications-games", "package-x-generic"]), Gtk.IconSize.DND)
        icon.set_pixel_size(28)
        top.pack_start(icon, False, False, 0)
        title = Gtk.Label(label=self.tr["extras_title"], xalign=0)
        title.get_style_context().add_class("doc-title")
        top.pack_start(title, True, True, 0)
        page.pack_start(top, False, False, 0)

        intro = Gtk.Label(label=self.tr["extras_intro"], xalign=0)
        intro.set_line_wrap(True)
        intro.set_max_width_chars(110)
        intro.get_style_context().add_class("picker-intro")
        page.pack_start(intro, False, False, 0)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        scrolled.set_min_content_height(300)
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_end(8)
        tiles = []
        apps_by_id = {}
        for group in load_extras():
            head = Gtk.Label(label=self.tr.get("cat_" + group["category"], group["category"]), xalign=0)
            head.get_style_context().add_class("picker-cat")
            head.set_margin_top(10)
            box.pack_start(head, False, False, 0)
            flow = Gtk.FlowBox()
            flow.set_selection_mode(Gtk.SelectionMode.NONE)
            flow.set_homogeneous(True)
            flow.set_min_children_per_line(4)
            flow.set_max_children_per_line(7)
            flow.set_column_spacing(10)
            flow.set_row_spacing(10)
            for app in group["apps"]:
                apps_by_id[app["id"]] = app
                if "script" in app:
                    done = os.path.exists(os.path.expanduser(app.get("check", "")))
                else:
                    done = app["id"] in installed
                tile = self.extras_tile(app, done)
                flow.add(tile)
                tiles.append((tile, app["id"]))
            box.pack_start(flow, False, False, 0)
        scrolled.add(box)
        page.pack_start(scrolled, True, True, 0)

        bar = Gtk.Box(spacing=10)
        bar.get_style_context().add_class("extras-bar")
        count = Gtk.Label(label=self.tr["extras_count"].format(n=0))
        count.get_style_context().add_class("picker-count")
        bar.pack_start(count, False, False, 0)
        install = Gtk.Button(label=self.tr["extras_install"])
        install.get_style_context().add_class("primary")
        install.set_sensitive(False)
        bar.pack_end(install, False, False, 0)
        cancel = Gtk.Button(label=self.tr["cancel"])
        cancel.get_style_context().add_class("ghost")
        cancel.connect("clicked", lambda *_: self.close_extras())
        bar.pack_end(cancel, False, False, 0)
        page.pack_start(bar, False, False, 0)

        def selected():
            return [app_id for tile, app_id in tiles if tile.get_active() and tile.get_sensitive()]

        def update(*_):
            chosen = selected()
            count.set_text(self.tr["extras_count"].format(n=len(chosen)))
            install.set_sensitive(bool(chosen))

        def do_install(*_):
            chosen = selected()
            self.close_extras()
            if not chosen:
                return
            # Flathub jednym poleceniem, a programy spoza Flathuba (np. Claude, Codex)
            # swoimi skryptami z /usr/share/orkalinux/extras
            steps = []
            flat = [a for a in chosen if "script" not in apps_by_id[a]]
            if flat:
                steps.append(shlex.join(["flatpak", "install", "-y", "--system", "flathub"] + flat))
            for a in chosen:
                app = apps_by_id[a]
                if "script" in app:
                    cmd = ["sh", os.path.join(EXTRAS_SCRIPTS, app["script"])]
                    steps.append(shlex.join((["sudo"] if app.get("root") else []) + cmd))
            self.run_in_terminal(["sh", "-c", " && ".join(steps)])

        for tile, _ in tiles:
            tile.connect("toggled", update)
        install.connect("clicked", do_install)

        old_page = self.pages.get_child_by_name("extras")
        if old_page is not None:
            self.pages.remove(old_page)
        self.pages.add_named(page, "extras")
        page.show_all()
        self.pages.set_visible_child_name("extras")

    def close_extras(self):
        self.pages.set_visible_child_name("home")

    def run_in_terminal(self, args):
        """Długie instalacje idą w Konsoli – widać postęp i ewentualny błąd."""
        command = shlex.join(args)
        done = shlex.quote(self.tr["term_done"])
        failed = shlex.quote(self.tr["term_failed"])
        # po sukcesie okno samo się zamyka, po błędzie czeka na Enter
        script = f"if {command}; then echo; echo {done}; sleep 3; else echo; echo {failed}; read -r _; fi"
        try:
            subprocess.Popen(["kitty", "sh", "-c", script])
        except OSError:
            dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                       message_type=Gtk.MessageType.ERROR,
                                       buttons=Gtk.ButtonsType.OK,
                                       text=self.tr["no_terminal"])
            dialog.run()
            dialog.destroy()

    def on_lang_changed(self, combo):
        lang = combo.get_active_id()
        if lang and lang != self.lang:
            self.lang = lang
            self.tr = TRANSLATIONS[lang]
            self.set_title(self.tr["title"])
            GLib.idle_add(self.build_ui)

    def on_dark_toggled(self, switch, _param):
        dark = switch.get_active()
        if dark == is_dark_mode():
            return
        # Bez --resetLayout: panel i ikony na pulpicie zostają, zmieniają się kolory i tapeta
        try:
            subprocess.Popen(["plasma-apply-lookandfeel", "-a", LOOK_DARK if dark else LOOK_LIGHT])
        except OSError:
            return
        set_gtk_dark(dark)
        self.set_light(not dark)

    def on_autostart_toggled(self, switch, _param):
        if switch.get_active():
            os.makedirs(os.path.dirname(AUTOSTART_FILE), exist_ok=True)
            with open(AUTOSTART_FILE, "w") as f:
                f.write("[Desktop Entry]\nType=Application\nName=OrkaLinux Hello\n"
                        "Exec=/usr/share/orkalinux-hello/orkalinux-hello.py\nIcon=orka-hello\n"
                        "X-KDE-autostart-after=panel\n")
        elif os.path.exists(AUTOSTART_FILE):
            os.remove(AUTOSTART_FILE)


if __name__ == "__main__":
    win = OrkaLinuxHello()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()
