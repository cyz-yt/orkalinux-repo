# OrkaLinux: GRUB czarno-biały, jak w CachyOS (tło to czarny obrazek,
# bo bez obrazka Debian wstawiłby swoją tapetę)
WALLPAPER=/usr/share/desktop-base/orkalinux-theme/grub/grub-16x9.png
COLOR_NORMAL=light-gray/black
COLOR_HIGHLIGHT=black/light-gray
